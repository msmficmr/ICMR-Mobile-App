import 'package:isar/isar.dart';

part 'personal_history_schema.g.dart';

@embedded
class PersonalHistory {
  late String uiTemplateId;
  late String templateName;
  late String versionNumber;
  late String firstQuestionId;
  late String fields;
}