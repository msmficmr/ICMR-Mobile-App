import 'package:isar/isar.dart';
import 'package:mhealth/isar_db_schema/personal_history_schema.dart';

part 'risk_assessment_questionaire.g.dart';

@collection
class RiskAssessmentQuestionaire {
  Id? id;
  PersonalHistory? personal_history;
}
